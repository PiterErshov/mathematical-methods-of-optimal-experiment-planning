import numpy as np

N = 10 # размерность информационной матрицы

def f_model(x, y): # функция модели
    return [1, x, y, x*y, x**2, y**2, x**2 * y, y**2 * x, x**3, y**3]

def creat_plan(N, n): # N - размер сетки, n - число наблюдений
    step = 2 / (N - 1)
    grid = np.arange(-1, 1 + 0.0001, step) # сетка с шагом step
    X = [] # массив сетки
    plan = [] # массив точек плана
    plan_w = [1 / n] * n # массив весов плана
    for x in grid:  # получаем начальный план
        for y in grid:
            X.extend([[x, y]])

    for i in range(n):
        plan.append(X[(i * 17) % (N**2)])
    return X, plan, plan_w

def M_mat(x_p, p): #Информационную матрицу M
    M = np.zeros(shape = (N, N))
    for i in range(N):
        for j in range(N):
            for k in range(len(x_p)):
                f = np.array(f_model(x_p[k][0], x_p[k][1]))
                M[i][j] += p[k] * f[i] * f[j]
    return M

def find_points(M, X, flag): # функция поиска экстремума
    fi = [] # массив значений экстремума
    M1 = np.linalg.inv(M) # получаем обратную матрицу от информационной матрицы M
    M2 = np.linalg.matrix_power(M1, 2) # получаем обратную матрицу в квадрате (так как в формуле для поиска экстремума есть
                                                                        # дифференциал от функцилнала критерия A по информационной матрице
                                                                        # то, при вычислении дифференциала получаем обратную матрицу в степени 2)
    for i in X: # получаем набор чисел для поиска экстремума (в данном варианте - наибольнее число)
        f_i = np.array(f_model(i[0], i[1])) # получаем вектор-столбец от функции модели
        buf = f_i.T.dot(M2) # умножаем вектор-строку от функции модели на обратную матрицу в кубе
        fi.append(buf.dot(f_i))# умножаем получившийся в предыдущем действии вектор на вектор-столбец от функции модели

    if flag == 0:
        extr = max(fi)
    else:
        extr = min(fi)
    for i in range(len(X)):
        if(extr == fi[i]):
            return i   # возвращаем наибольшее значение (экстремум) и точку экстремума

def find_point(x, X): # проверяем принадлежность точки x массиву X
    for i in X:
        if x[0] == i[0] and x[1] == i[1]:
            return 1
    return 0

def creat_new_multi(X, xs): # создаём новый массив, исключая элементы массива xs
    X_new = []
    for i in X:
        if find_point(i, xs) != 1:
            X_new.append(i)
    return X_new

def funk(plan, plan_w): # функция получения значения функционала от криетрия оптимальности
    M = M_mat(plan, plan_w)
    M1 = np.linalg.inv(M)  # получаем обратную матрицу от информационной матрицы M
    F = -np.trace(M1)
    return (F)


def building(plan, plan_w, X): # функция построения оптимального плана
    i = 0 # счётчик успешных замен точек
    X_res = X.copy() # копируем массив сетки
    new_plan = plan.copy() # копируем точки плана
    new_plan_i = new_plan.copy() # создаём следующую копию точек плана для полученния нового значения функционала

    while(True):
        M = M_mat(new_plan_i, plan_w)
        old_funk = funk(new_plan_i, plan_w) # получаем старое значение функционала

        if(i == 0): # если ноль замен, то обновляем план
            new_plan = new_plan_i.copy()

        X_new = creat_new_multi(X_res, new_plan_i) # получаем новую сетку, без точек плана
        X_max = find_points(M, X_new, 0) # максимум на множестве X \ plan (x*)
        X_min = find_points(M, new_plan, 1) #  минимум на множестве plan (x**)

        old_plan = new_plan_i.copy() # сохраняем старый план
        # заменям точку x** на точку x*
        x_star_2 = new_plan_i[X_min]
        new_plan_i[X_min] = X_res[X_max]

        new_funk = funk(new_plan_i, plan_w) # получаем новый функционал

        if (new_funk > old_funk): # пункт 6 алгоритма
            i += 1 # увеличиваем счётких замен точек
            del_point = X_res[X_max] # исключаем точку x* из рассмотрения
            X_res.remove(del_point)
            if (x_star_2 in X_res): # исключаем точку x** из рассмотрения
                X_res.remove(x_star_2)
        else:
            if (i == 0): # больше ничего нельзя сделать, завершить вычисления (подпункт b пункта 6)
                return new_plan
            else:        # возможно еще можно найти "удачные" замены (переход к пункту 2)
                new_plan_i = old_plan.copy()
                i = 0

def main():
    g = [30, 40]
    obser = [20, 25, 30, 35, 40]

    for i in g:
        for j in obser:
            print("Сетка", i, "x", i, "Число наблюдений", j)
            X, plan, plan_w = creat_plan(i, j)
            print("Функционал до оптимизации плана", funk(plan, plan_w))
            optimal_plan = building(plan, plan_w, X)
            print("Функционал после оптимизации плана", funk(optimal_plan, plan_w), "\n")

main()
